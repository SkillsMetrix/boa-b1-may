
from fastapi import FastAPI

app= FastAPI()

@app.get("/")
def loadMsg():
    return {"message":"Welcome to Fast API"}