userAge=input('Enter your age')

age= int(userAge)

if(age <0):
    print('Enter Valid age')
elif age < 18:
    print('Not Allowed to Vote')
elif age >=18 and age <79:
    print('Allwed to Vote')
else:
    print('senior citizen')

