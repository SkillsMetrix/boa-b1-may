
def showWelcome():
    print('welcome message')

showWelcome()


def calculate(x,y):
    return x+y

print(calculate(21,34))