firstValue=int(input('Enter First Value'))
secondValue=int(input('Enter Second Value'))

addition=firstValue+secondValue
print(f"Addition is {addition}")