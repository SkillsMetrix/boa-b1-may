
from RBI import RBI

class ICICI(RBI):
    def allocateCard(self):
        print('card allocated')



ici= ICICI()
print(ici)