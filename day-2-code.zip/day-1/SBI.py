
from RBI import RBI

class SBI(RBI):
    def allocateCard(self):
        print('card allocated')
    def deposit(self):
        return f"deposited in SBI"
    def withdraw(self):
        return f"withdraw from SBI"


sbi= SBI()
print(sbi.withdraw())
print(sbi.deposit())