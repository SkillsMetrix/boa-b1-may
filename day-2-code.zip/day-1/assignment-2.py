
#declare empty array
use_numbers=[]

# ask the user to add the values

data= int(input(' how many numbers you wana add ?'))

# store the values

for i in range(data):
    num=int(input(f"Enter numbers{i+1}"))
    use_numbers.append(num)
    print(use_numbers)

# print even and odd numbers

for findValue in use_numbers:
    if(findValue%2==0):
        print(f"{findValue} is even")
    else:
         print(f"{findValue} is odd")


