
# style-1
def sumOfArray(arr):
    total=0
    for num in arr:
        total+=num
    return total

numbers=[12,13,14,15]
result= sumOfArray(numbers)
print(f"the addition is {result}")


# style-2
def sumOfArray2(*arr):
    total=0
    for num in arr:
        total+=num
    return total

 
result= sumOfArray2(12,13,14,15)
print(f"the addition is {result}")
