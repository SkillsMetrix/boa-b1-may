# CLASS
class Employee:
    empName='Santosh'
    empEmail='santosh@mail.com'

    def takeProject(self):
        print(f"Project is undertaking")

# OBJECT
santosh=  Employee()
print(santosh.empName,santosh.empEmail)
santosh.takeProject()