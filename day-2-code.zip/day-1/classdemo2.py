
class UserApp:
    name=''
    email=''
    city=''

# constructor

    def __init__(self,name='admin',email='admin@amil.com',city='pune'):
        self.name=name
        self.email=email
        self.city=city

    def printValues(self):
        print(f"{self.name}** {self.email} ** {self.city}")
        
    def __str__(self):
        return f"{self.name}** {self.email} ** {self.city}"

userone= UserApp()
usertwo= UserApp('manager','man@mail.com')
print(userone)
print(usertwo)
