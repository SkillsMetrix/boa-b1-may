
userNames=['Admin','Manager','QA']

for uname in userNames:
    print(uname)

