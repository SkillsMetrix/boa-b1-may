# variable declarations demo

userName='Admin'
print(userName)
userName='Manager'

userName=30
print(userName)

# if conditions, dont use cruly braces ,insted use :

a=10
b=20
if b > a:
    print('statement is true')
else:
    print('statement is false')

# print all the values togather
myName='Amarjeet Singh'
city='Pune'
pin=12345
state='MH'
print(f"My Name is {myName}, my City is {city} and PinCode is {pin}")
