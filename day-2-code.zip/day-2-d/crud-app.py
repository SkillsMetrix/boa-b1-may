
from fastapi import Body,FastAPI,HTTPException,status,Depends
from random import randrange
from schemas import UserPost
#from .database import engine,get_db
from sqlalchemy.orm import Session
#from .import models
from .routers import post
app= FastAPI()

#models.Base.metadata.create_all(bind=engine)
app.include_router(post.router)

 

