
from sqlalchemy import Column,String
from .database import Base

class UserPosts(Base):
    __tablename__="post"
    title=Column(String)
    content=Column(String)