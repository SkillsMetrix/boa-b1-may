
from fastapi import Body,FastAPI,HTTPException,status,Depends,APIRouter
from random import randrange
from .. schemas import UserPost
from sqlalchemy.orm import Session
#from .. import schemas
router= APIRouter(tags=["userposts"])

 

user_post=[]

# initialize DB Connect
""" @app.get("/testconn")
def testcConn(db:Session=Depends(get_db)):
    return {"status":"success"} """

@router.get("/loadall")
def loadData():
    return {"message":user_post}

@router.post("/createpost")
def createPost(newPost:UserPost):
    data=newPost.model_dump()
    data['id']=randrange(0,10000)
    user_post.append(data)

    return {"message":data}

# reusable func
def findPost(id):
    for i,p in enumerate(user_post):
        if p['id'] == id:
            print(p)
            return i

@router.get("/loadpost/{id}")
def findPostById(id:int):
    findData=findPost(id)
    if findData ==None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="User not Found")
    print(findData)
    return {"data": findData}


@router.delete("/deletepost/{id}")
def deletePostById(id:int):
    findData=findPost(id)
    if findData ==None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="User not Found")
    user_post.pop(findData)
    return {"data": "user deleted"}


@router.put("/updatepost/{id}")
def deletePostById(id:int,post:UserPost):
    findData=findPost(id)
    if findData ==None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="User not Found")
    data=post.model_dump()
    data['id']=id
    user_post[findData]=post
    
    return {"data": "user updated"}